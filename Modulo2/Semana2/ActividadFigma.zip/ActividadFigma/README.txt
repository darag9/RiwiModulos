Colores :3

blanco: #FFFFFF
background: #333333
boton: #FDB623

Dimensiones:

width: 428px
height: 926px

Figma:

https://www.figma.com/design/RXthZSmSTyW25g2MgrZBxH/Sin-t%C3%ADtulo?node-id=0-1&t=TUzrX8AJf3GCDApU-1
